#!/bin/bash

#PBS -N myjob
#PBS -q morgan3
#PBS -l nodes=1:ppn=1
#PBS -l walltime=72:00:00
#PBS -j oe

NN=`cat $PBS_NODEFILE | wc -l`
echo "Processors received = "$NN
cd $PBS_O_WORKDIR
echo "PBS_NODEFILE"
cat $PBS_NODEFILE

#---------------------------------------

date

  awk '{if(NR==2){print "85 85 50"} else{print}}' chk.inp > chktemp
  for n in `seq 1 21`
  do
    awk 'NR==1{s=gensub(/extrj/,"extrj-'$n'","g"); print s}; NR>=2{print}' chktemp > chk-grain$igrain-$n.inp
    chkorient.x < chk-grain$igrain-$n.inp >> chk-grain$igrain.out
    rm chk-grain$igrain-$n.inp
  done
  rm chktemp

date

