#!/bin/bash

#PBS -N myjob
#PBS -q morgan3
#PBS -l nodes=1:ppn=1
#PBS -l walltime=72:00:00
#PBS -j oe

NN=`cat $PBS_NODEFILE | wc -l`
echo "Processors received = "$NN
cd $PBS_O_WORKDIR
echo "PBS_NODEFILE"
cat $PBS_NODEFILE

#---------------------------------------

date

for n in `seq 1 21`
do
  extrj.sh 300-def* $n
  mv extrj.xyz extrj-$n.xyz
done

date

